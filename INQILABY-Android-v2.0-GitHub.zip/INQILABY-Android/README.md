# INQILABY Android — Dashboard 2.0

INQILABY adalah fondasi aplikasi Android **Ramadan+ — Journey to Better Muslim** dengan tampilan pastel modern. Target minimum Android 10 (API 29).

## Isi versi 2.0
- Dashboard yang diperbarui: salam pembuka, tanggal lokal, kartu Ramadan+ Journey, jadwal salat, progres amalan, akses cepat Qur'an/Doa/Amalan, dan pengingat kebaikan.
- Navigasi bawah: Beranda, Qur'an, Amalan, Doa, Lainnya.
- Checklist amalan 7 item tetap tersimpan secara lokal menggunakan Preferences DataStore.
- GitHub Actions untuk membangun APK debug secara otomatis.

## Catatan status fitur
- **Sudah berfungsi:** dashboard UI, navigasi, checklist amalan, penyimpanan checklist lokal.
- **Belum diaktifkan:** jadwal salat dan waktu berbuka masih `--:--`; lokasi belum dikonfigurasi.
- **Belum diimplementasikan:** database konten Al-Qur'an, target khatam yang tersimpan, koleksi doa/dzikir, kalender Hijriah, zakat, sinkronisasi/backup, dan notifikasi.
- Aplikasi dapat dibuka tanpa koneksi internet; fitur yang membutuhkan data online belum tersedia.

## Build APK melalui GitHub (disarankan)
1. Buat repository baru di GitHub, misalnya `inqilaby-android`.
2. Upload seluruh isi folder proyek ini ke root repository. Pastikan folder `.github/workflows/` ikut terunggah.
3. Buka tab **Actions** di repository. Jika diminta, aktifkan GitHub Actions.
4. Workflow **Build INQILABY APK** berjalan otomatis setelah push ke branch `main`/`master`. Kamu juga bisa memilih workflow lalu tekan **Run workflow**.
5. Setelah status build hijau, buka hasil workflow dan cari bagian **Artifacts**.
6. Unduh `INQILABY-debug-apk`, ekstrak ZIP, lalu install `app-debug.apk` di HP Android. Jika diminta, izinkan instalasi dari sumber tersebut.

## Build lokal (opsional)
- Android Studio dengan JDK 17 dan Android SDK Platform 35.
- Gunakan Gradle 8.11.1, lalu jalankan `gradle assembleDebug` dari root proyek.
- APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Teknologi
- Kotlin 2.1.20
- Jetpack Compose + Material 3
- Android Gradle Plugin 8.9.2
- Gradle 8.11.1
- Preferences DataStore 1.1.4
