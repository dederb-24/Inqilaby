package com.inqilaby.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.inqilaby.app.ui.theme.Mint

private val worshipItems = listOf(
    "Salat Subuh", "Salat Dzuhur", "Salat Ashar", "Salat Maghrib",
    "Salat Isya", "Membaca Al-Qur'an", "Tarawih / Qiyam"
)

@Composable
fun WorshipScreen(
    modifier: Modifier = Modifier,
    checked: List<Boolean>,
    onCheckedChange: (Int, Boolean) -> Unit
) {
    Column(
        modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("My Worship 🌷", style = MaterialTheme.typography.headlineMedium)
        Text("Small steps, meaningful journey.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card(colors = CardDefaults.cardColors(containerColor = Mint), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("DAILY PROGRESS", style = MaterialTheme.typography.labelMedium)
                Text("${checked.count { it }}/7 Activities", style = MaterialTheme.typography.headlineMedium)
                LinearProgressIndicator(
                    progress = { checked.count { it } / 7f },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Daily Checklist", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                worshipItems.forEachIndexed { index, label ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(label, modifier = Modifier.weight(1f))
                        Checkbox(
                            checked = checked.getOrElse(index) { false },
                            onCheckedChange = { onCheckedChange(index, it) }
                        )
                    }
                }
            }
        }
    }
}
