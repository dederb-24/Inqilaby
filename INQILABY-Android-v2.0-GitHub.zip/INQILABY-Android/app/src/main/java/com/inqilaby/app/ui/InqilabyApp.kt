package com.inqilaby.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.inqilaby.app.data.PreferencesRepository
import com.inqilaby.app.ui.screens.DashboardScreen
import com.inqilaby.app.ui.screens.PlaceholderScreen
import com.inqilaby.app.ui.screens.WorshipScreen

private data class Tab(val label: String, val icon: ImageVector)

@Composable
fun InqilabyApp() {
    val tabs = listOf(
        Tab("Beranda", Icons.Default.Home),
        Tab("Qur'an", Icons.Default.Book),
        Tab("Amalan", Icons.Default.CalendarMonth),
        Tab("Doa", Icons.Default.Favorite),
        Tab("Lainnya", Icons.Default.Explore)
    )
    var selected by remember { mutableIntStateOf(0) }

    val context = LocalContext.current
    val repository = remember { PreferencesRepository(context) }
    val scope = rememberCoroutineScope()
    val worship by repository.worshipState.collectAsStateWithLifecycle(initialValue = List(7) { false })

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        icon = { androidx.compose.material3.Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        when (selected) {
            0 -> DashboardScreen(
                modifier = Modifier.padding(padding),
                completed = worship.count { it },
                onOpenWorship = { selected = 2 },
                onOpenQuran = { selected = 1 },
                onOpenDua = { selected = 3 }
            )
            1 -> PlaceholderScreen("Al-Qur'an", "Daftar surah, juz, penanda bacaan, dan target khatam akan dikembangkan pada tahap berikutnya.", Modifier.padding(padding))
            2 -> WorshipScreen(
                modifier = Modifier.padding(padding),
                checked = worship,
                onCheckedChange = { index, value ->
                    // Persisted locally using DataStore.
                    scope.launch {
                        repository.setWorship(index, value)
                    }
                }
            )
            3 -> PlaceholderScreen("Doa & Dzikir", "Koleksi doa harian, dzikir, favorit, dan tasbih digital.", Modifier.padding(padding))
            else -> PlaceholderScreen("Fitur INQILABY", "Jadwal salat, zakat, sedekah, keluarga, kalender, muhasabah, dan laporan Ramadan.", Modifier.padding(padding))
        }
    }
}
