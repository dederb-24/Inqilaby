package com.inqilaby.app.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFFFF9F1)
val Ink = Color(0xFF282A39)
val Muted = Color(0xFF858391)
val Lavender = Color(0xFFE5E1FF)
val LavenderInk = Color(0xFF6254A6)
val Peach = Color(0xFFFFDCCB)
val Mint = Color(0xFFD7F0E4)
val Pink = Color(0xFFF8DCE8)
val Butter = Color(0xFFFFF0BD)
val Sky = Color(0xFFD9EBFF)
