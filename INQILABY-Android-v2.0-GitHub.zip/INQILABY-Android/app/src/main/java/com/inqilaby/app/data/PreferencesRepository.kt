package com.inqilaby.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "inqilaby_preferences")

class PreferencesRepository(private val context: Context) {
    private val worshipKeys = listOf(
        booleanPreferencesKey("worship_fajr"),
        booleanPreferencesKey("worship_dhuhr"),
        booleanPreferencesKey("worship_asr"),
        booleanPreferencesKey("worship_maghrib"),
        booleanPreferencesKey("worship_isha"),
        booleanPreferencesKey("worship_quran"),
        booleanPreferencesKey("worship_tarawih")
    )

    val worshipState: Flow<List<Boolean>> = context.dataStore.data.map { prefs ->
        worshipKeys.map { key -> prefs[key] ?: false }
    }

    suspend fun setWorship(index: Int, checked: Boolean) {
        if (index !in worshipKeys.indices) return
        context.dataStore.edit { prefs -> prefs[worshipKeys[index]] = checked }
    }
}
