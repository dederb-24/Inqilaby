package com.inqilaby.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val InqilabyColors = lightColorScheme(
    primary = LavenderInk,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    secondary = androidx.compose.ui.graphics.Color(0xFF62AF8A),
    background = Cream,
    surface = androidx.compose.ui.graphics.Color.White,
    onBackground = Ink,
    onSurface = Ink
)

@Composable
fun InqilabyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = InqilabyColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
