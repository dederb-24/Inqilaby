package com.inqilaby.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.inqilaby.app.ui.theme.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    completed: Int,
    onOpenWorship: () -> Unit,
    onOpenQuran: () -> Unit = {},
    onOpenDua: () -> Unit = {}
) {
    val today = LocalDate.now()
    val dateText = today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID")))
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("INQILABY ✦", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = LavenderInk)
                Text(dateText.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.labelMedium, color = Muted)
            }
            Box(Modifier.size(44.dp).background(Lavender, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, contentDescription = "Profil", tint = LavenderInk)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Assalamu'alaikum! 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
            Text("Setiap hari adalah kesempatan untuk menjadi lebih baik.", style = MaterialTheme.typography.bodyMedium, color = Muted)
        }

        // Seasonal journey card. Prayer and fasting times remain clearly marked as not configured.
        Card(colors = CardDefaults.cardColors(containerColor = Lavender), shape = RoundedCornerShape(28.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = LavenderInk, modifier = Modifier.size(17.dp))
                    Text("RAMADAN+ JOURNEY", color = LavenderInk, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Text("Your journey to a better Muslim", color = Ink, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Bangun kebiasaan baik, satu langkah setiap hari.", color = LavenderInk, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider(color = Color(0xFFC9C0F2))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Waktu berbuka / Maghrib", color = LavenderInk, style = MaterialTheme.typography.labelMedium)
                        Text("Atur lokasi terlebih dahulu", color = Ink, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.NightsStay, contentDescription = null, tint = LavenderInk, modifier = Modifier.size(38.dp))
                }
            }
        }

        SectionHeading("Jadwal salat", "Waktu belum diatur")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrayerTile("Subuh", "--:--", Sky, Modifier.weight(1f))
                PrayerTile("Dzuhur", "--:--", Butter, Modifier.weight(1f))
                PrayerTile("Ashar", "--:--", Mint, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrayerTile("Maghrib", "--:--", Peach, Modifier.weight(1f))
                PrayerTile("Isya", "--:--", Pink, Modifier.weight(1f))
                PrayerTile("Imsak", "--:--", Lavender, Modifier.weight(1f))
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Amalan hari ini", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("$completed/7", color = Color(0xFF397C65), fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { completed / 7f }, modifier = Modifier.fillMaxWidth().height(9.dp),
                    color = Color(0xFF62AF8A), trackColor = Mint
                )
                Text(if (completed == 7) "Alhamdulillah, semua target selesai!" else "Terus jaga konsistensi. Sedikit demi sedikit.", color = Muted, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onOpenWorship, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp)); Text("Buka checklist amalan")
                }
            }
        }

        SectionHeading("Mulai dari sini", "Akses cepat")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("Al-Qur'an", "Target bacaan", Icons.Default.MenuBook, Peach, onOpenQuran, Modifier.weight(1f))
            QuickAction("Doa & Dzikir", "Kumpulan doa", Icons.Default.Favorite, Pink, onOpenDua, Modifier.weight(1f))
            QuickAction("Amalan", "Pantau ibadah", Icons.Default.CheckCircle, Mint, onOpenWorship, Modifier.weight(1f))
        }

        Card(colors = CardDefaults.cardColors(containerColor = Butter), shape = RoundedCornerShape(24.dp)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color(0xFF98752A), modifier = Modifier.size(24.dp))
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Pengingat kebaikan", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Jangan menunggu sempurna untuk memulai. Lakukan kebaikan kecil dengan istiqamah.", color = Color(0xFF78622D), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        Text("INQILABY • Ramadan+", modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun SectionHeading(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Muted)
    }
}

@Composable
private fun PrayerTile(name: String, time: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(name, style = MaterialTheme.typography.labelSmall, color = Ink)
            Text(time, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
        }
    }
}

@Composable
private fun QuickAction(title: String, subtitle: String, icon: ImageVector, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = color), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = Ink, modifier = Modifier.size(22.dp))
            Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Muted)
        }
    }
}
